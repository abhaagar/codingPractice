#include "global.h"

//---- Wall ---------------------------------------------------------

void PrintIndent(int indent) {
	for(int i = 0; i < indent; i++) {
		printf(" ");
	}
}
