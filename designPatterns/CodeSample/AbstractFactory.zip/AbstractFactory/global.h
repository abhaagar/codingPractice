//-*-Mode: C++;-*-
#ifndef _global_h_
#define _global_h_

#include <stdio.h>

typedef enum Direction { North, South, East, West };

void PrintIndent(int indent);

#endif
