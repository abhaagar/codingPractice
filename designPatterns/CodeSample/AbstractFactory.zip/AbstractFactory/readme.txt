From maze0:
http://www.swe.uni-linz.ac.at/people/froehlich/OOA/examples/

I added two files:
_AbstractFactory.cpp - project directory
_main.cpp - CTTL prototype

output1.txt and output2.txt demonstrate what you get by changing BOOL_ABSTRACT_FACTORY_BOMBED true/false
