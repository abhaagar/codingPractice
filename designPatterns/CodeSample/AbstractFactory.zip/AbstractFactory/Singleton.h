//-*-Mode: C++;-*-
#ifndef _Singleton_h_
#define _Singleton_h_

#include "MazeFactory.h"

class MazeFactory * FactoryInstance();

#endif
